# IELTS Global Test Centre Scraper 🌍📝

A Streamlit web app that scrapes detailed IELTS test centre information from [ielts.org](https://ielts.org).

## 🧠 Features
- Scrapes by country
- Extracts test centre name, address, UKVI flag, test types, prices
- Excel download
- Simple Streamlit interface

## 📦 Local Setup

```bash
pip install -r requirements.txt
streamlit run ielts_scraper.py
```

## 🌐 Deploy on Streamlit Cloud

1. Create a GitHub repo
2. Upload these files
3. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
4. Deploy your app using `ielts_scraper.py`

## 📬 Built by [Martin Chadwick](https://github.com/thirdeyeopen-martin)
